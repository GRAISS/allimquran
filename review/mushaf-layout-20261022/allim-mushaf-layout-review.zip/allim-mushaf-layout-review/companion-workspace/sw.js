"use strict";

var cacheName = "quran-companion-prototype-v94";
var localAssets = [
  "./index.html?v=93",
  "./styles.css?v=93",
  "./quran-data.js?v=80",
  "./tafsir-data.js?v=80",
  "./fawaid-data.js?v=81",
  "./reading-sync.js?v=91",
  "./reading-journal.js?v=91",
  "./memory-journey.js?v=92",
  "./app.js?v=93",
  "./manifest.webmanifest?v=80",
  "./allim-brand-icon.png",
  "./assets/audio/allim-dua-ar-v2.m4a"
];

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(cacheName).then(function (cache) {
      return cache.addAll(localAssets);
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (key) {
        return key.indexOf("quran-companion-prototype-") === 0 && key !== cacheName;
      }).map(function (key) {
        return caches.delete(key);
      }));
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", function (event) {
  if (event.request.method !== "GET") return;
  var requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;
  var allowed = localAssets.some(function (asset) {
    return new URL(asset, self.registration.scope).pathname === requestUrl.pathname;
  });
  var appNavigation = event.request.mode === "navigate" &&
    requestUrl.pathname === new URL("./", self.registration.scope).pathname;
  if (!allowed && !appNavigation) return;
  event.respondWith(
    fetch(event.request).then(function (response) {
      if (allowed && response.ok && response.type !== "opaque" && !response.redirected) {
        var copy = response.clone();
        event.waitUntil(caches.open(cacheName).then(function (cache) {
          return cache.put(event.request, copy);
        }).catch(function () { return null; }));
      }
      return response;
    }).catch(function () {
      return caches.match(event.request).then(function (cached) {
        if (cached) return cached;
        if (event.request.mode === "navigate") return caches.match("./index.html?v=93").then(function (page) { return page || Response.error(); });
        return Response.error();
      });
    })
  );
});
