'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const handlers = {}, removed = [], stored = [];
const cache = { addAll: async paths => { stored.push(...paths); }, put: async () => {} };
const context = {
  URL, Response,
  self: { location: { origin: 'https://example.test' }, registration: { scope: 'https://example.test/' },
    addEventListener: (name, fn) => { handlers[name] = fn; }, skipWaiting() {}, clients: { claim() {} } },
  caches: { open: async () => cache, keys: async () => ['quran-companion-prototype-v88', 'other-product', 'quran-companion-prototype-v92', 'quran-companion-prototype-v93', 'quran-companion-prototype-v94'],
    delete: async key => { removed.push(key); }, match: async () => undefined },
  fetch: async () => { throw Error('offline'); }
};
vm.runInNewContext(fs.readFileSync(require.resolve('../sw.js'), 'utf8'), context);
async function lifecycle(name) { let promise; handlers[name]({ waitUntil: p => { promise = p; } }); await promise; }
function request(path, options = {}) {
  let response;
  handlers.fetch({ request: { method: 'GET', mode: 'cors', url: 'https://example.test' + path, ...options },
    respondWith: p => { response = p; }, waitUntil() {} });
  return response;
}
(async () => {
  await lifecycle('install');
  for (const name of ['reading-journal.js', 'reading-sync.js', 'memory-journey.js', 'fawaid-data.js']) {
    assert(stored.some(path => path.includes(name)), name + ' must be available offline');
  }
  await lifecycle('activate');
  assert.deepEqual(removed, ['quran-companion-prototype-v88', 'quran-companion-prototype-v92', 'quran-companion-prototype-v93']);
  for (const path of ['/api/method/private', '/login', '/academy', '/account', '/private/files/history.json']) {
    assert.equal(request(path, { mode: 'navigate' }), undefined, path + ' must bypass the public cache');
  }
  assert.equal(request('/app.js', { method: 'POST' }), undefined);
  assert.equal(request('/app.js', { url: 'https://other.test/app.js' }), undefined);
  const offline = await request('/app.js?v=91');
  assert.equal(offline.type, 'error');
  console.log('Offline cache: complete module set, private routes bypassed, other caches preserved, offline failures handled.');
})().catch(error => { console.error(error); process.exitCode = 1; });
