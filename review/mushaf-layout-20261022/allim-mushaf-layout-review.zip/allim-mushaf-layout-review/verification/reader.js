  var mushafReadingPreferences;
  function getMushafReadingPreferences() {
    if (mushafReadingPreferences) return mushafReadingPreferences;
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem("allim-mushaf-reading-v1") || "{}"); } catch (error) { /* Use readable defaults when storage is unavailable. */ }
    if (!saved || typeof saved !== "object") saved = {};
    mushafReadingPreferences = {
      layout: ["page", "adaptive"].indexOf(saved.layout) >= 0 ? saved.layout : (window.innerWidth <= 620 ? "adaptive" : "page"),
      size: Number.isFinite(Number(saved.size)) && Number(saved.size) >= 28 && Number(saved.size) <= 52 ? Math.round(Number(saved.size) / 2) * 2 : 36
    };
    return mushafReadingPreferences;
  }

  function applyMushafReadingLayout(container) {
    var preferences = getMushafReadingPreferences();
    var adaptive = preferences.layout === "adaptive";
    if (container) {
      container.setAttribute("data-reading-layout", preferences.layout);
      container.style.setProperty("--mushaf-reading-size", preferences.size + "px");
      container.querySelectorAll(".mushaf-glyph[data-readable-text]").forEach(function (glyph) {
        if (!glyph.hasAttribute("data-page-glyph")) glyph.setAttribute("data-page-glyph", glyph.textContent);
        glyph.textContent = glyph.getAttribute(adaptive ? "data-readable-text" : "data-page-glyph");
      });
    }
    document.querySelectorAll("[data-mushaf-layout]").forEach(function (button) {
      button.setAttribute("aria-pressed", String(button.getAttribute("data-mushaf-layout") === preferences.layout));
    });
    var down = document.getElementById("mushaf-size-down");
    var up = document.getElementById("mushaf-size-up");
    var fontSelect = document.getElementById("mushaf-font-select");
    if (fontSelect) fontSelect.disabled = adaptive;
    var value = document.getElementById("mushaf-size-value");
    if (down) down.disabled = adaptive && preferences.size <= 28;
    if (up) up.disabled = adaptive && preferences.size >= 52;
    if (value) value.textContent = adaptive ? formatMetric(preferences.size) : "—";
    return adaptive;
  }

  function changeMushafReadingPreferences(layout, delta) {
    var container = document.getElementById("mushaf-page");
    var scroller = document.getElementById("ayah-wrap");
    var wasAtTop = scroller && scroller.scrollTop < 2;
    var anchor = null;
    var offset = 0;
    if (container && scroller) {
      var top = scroller.getBoundingClientRect().top;
      anchor = Array.prototype.find.call(container.querySelectorAll(".mushaf-glyph"), function (node) { return node.getBoundingClientRect().bottom > top + 8; });
      if (anchor) offset = anchor.getBoundingClientRect().top - top;
    }
    var preferences = getMushafReadingPreferences();
    preferences.layout = layout;
    preferences.size = Math.max(28, Math.min(52, preferences.size + delta));
    try { localStorage.setItem("allim-mushaf-reading-v1", JSON.stringify(preferences)); }
    catch (error) { showToast(t("mushafSizeNotSaved")); }
    fitMushafLines(container);
    window.requestAnimationFrame(function () {
      if (wasAtTop && scroller) { scroller.scrollTop = 0; return; }
      if (anchor && anchor.isConnected && scroller) scroller.scrollTop += anchor.getBoundingClientRect().top - scroller.getBoundingClientRect().top - offset;
    });
  }

  function initMushafReadingControls() {
    initMushafWorkspace();
    document.querySelectorAll("[data-mushaf-layout]").forEach(function (button) {
      button.addEventListener("click", function () { changeMushafReadingPreferences(button.getAttribute("data-mushaf-layout"), 0); });
    });
    document.getElementById("mushaf-size-down").addEventListener("click", function () { changeMushafReadingPreferences("adaptive", -2); });
    document.getElementById("mushaf-size-up").addEventListener("click", function () { changeMushafReadingPreferences("adaptive", 2); });
    applyMushafReadingLayout(document.getElementById("mushaf-page"));
  }
