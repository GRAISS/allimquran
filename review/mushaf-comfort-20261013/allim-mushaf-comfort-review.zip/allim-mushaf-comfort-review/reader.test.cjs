'use strict';
const {readFileSync}=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const script=readFileSync(path.join(__dirname,'reader.js'),'utf8');
const app=readFileSync(path.join(__dirname,'canonical/javascript.js'),'utf8');
function glyph(word){
 const attrs={'data-readable-text':word.text_qpc_hafs};
 return {textContent:word.code_v1,hasAttribute:k=>k in attrs,getAttribute:k=>attrs[k],setAttribute:(k,v)=>attrs[k]=v};
}
function env(saved,width=390){
 let stored,toast;
 const controls={};for(const id of ['mushaf-size-down','mushaf-size-up','mushaf-size-value'])controls[id]={};
 const context={Number,Math,JSON,localStorage:{getItem:()=>saved,setItem:(k,v)=>{stored=v;}},window:{innerWidth:width,requestAnimationFrame:f=>f()},document:{getElementById:k=>controls[k],querySelectorAll:()=>[]},formatMetric:String,t:k=>k,showToast:m=>{toast=m;},fitMushafLines:()=>{}};
 vm.createContext(context);vm.runInContext(script,context);
 return {context,controls,getStored:()=>stored,getToast:()=>toast};
}
for(const bad of [null,'{','null','false','[]','{"size":900,"layout":"bad"}','{"size":0}']){
 const {context}=env(bad);const p=context.getMushafReadingPreferences();assert.equal(p.size,36);assert.equal(p.layout,'adaptive');
}
assert.equal(env(null,1280).context.getMushafReadingPreferences().layout,'page');
const e=env('{"layout":"page","size":40}');assert.equal(e.context.getMushafReadingPreferences().size,40);
e.context.changeMushafReadingPreferences('adaptive',2);assert.equal(JSON.parse(e.getStored()).size,42);
e.context.localStorage.setItem=()=>{throw Error('denied');};e.context.changeMushafReadingPreferences('adaptive',20);assert.equal(e.context.getMushafReadingPreferences().size,52);assert.equal(e.getToast(),'mushafSizeNotSaved');
const sourceCounts={};
for(const p of [1,2,3,604]){
 const words=JSON.parse(readFileSync(path.join(__dirname,`fixtures/page-${p}.json`))).verses.flatMap(v=>v.words);
 assert(words.every(w=>typeof w.text_qpc_hafs==='string'&&w.text_qpc_hafs.length));
 const nodes=words.map(glyph),styles={},attrs={};
 const container={setAttribute:(k,v)=>attrs[k]=v,style:{setProperty:(k,v)=>styles[k]=v},querySelectorAll:()=>nodes};
 const {context}=env(null);context.applyMushafReadingLayout(container);
 assert.deepEqual(nodes.map(n=>n.textContent),words.map(w=>w.text_qpc_hafs));
 context.getMushafReadingPreferences().layout='page';context.applyMushafReadingLayout(container);
 assert.deepEqual(nodes.map(n=>n.textContent),words.map(w=>w.code_v1));
 context.getMushafReadingPreferences().layout='adaptive';context.applyMushafReadingLayout(container);
 assert.deepEqual(nodes.map(n=>n.textContent),words.map(w=>w.text_qpc_hafs));sourceCounts[p]=nodes.length;
}
function fn(name){const start=app.indexOf('  function '+name+'(');assert(start>=0);const end=app.indexOf('\n  function ',start+10);return app.slice(start,end);}
function swipes(){
 const events={},moves=[];
 const c={window:{visualViewport:{scale:1}},getMushafReadingPreferences:()=>({layout:'page'}),document:{getElementById:()=>({addEventListener:(name,fn)=>events[name]=fn})},mushafSwipeStart:null,navigateMushafPage:direction=>moves.push(direction)};
 const start=app.indexOf('    var mushafPage = document.getElementById("mushaf-page");');
 const end=app.indexOf('    document.getElementById("mushaf-font-select").addEventListener',start);
 vm.createContext(c);vm.runInContext(app.slice(start,end),c);
 const touch=(x,y)=>({clientX:x,clientY:y});
 events.touchstart({touches:[touch(200,100)]});events.touchstart({touches:[touch(200,100),touch(230,100)]});events.touchend({touches:[],changedTouches:[touch(100,100)]});assert.equal(moves.length,0);
 events.touchstart({touches:[touch(200,100)]});events.touchend({touches:[],changedTouches:[touch(120,250)]});assert.equal(moves.length,0);
 c.window.visualViewport.scale=2;events.touchstart({touches:[touch(200,100)]});events.touchend({touches:[],changedTouches:[touch(100,100)]});assert.equal(moves.length,0);
 c.window.visualViewport.scale=1;events.touchstart({touches:[touch(200,100)]});events.touchend({touches:[],changedTouches:[touch(100,100)]});assert.deepEqual(moves,[1]);
 c.getMushafReadingPreferences=()=>({layout:'adaptive'});events.touchstart({touches:[touch(200,100)]});events.touchend({touches:[],changedTouches:[touch(100,100)]});assert.deepEqual(moves,[1]);
}
swipes();
async function loading(){
 const resolvers=[],rendered=[],activated=[],controls={};
 for(const id of ['mushaf-page','mushaf-page-number','mushaf-prev-page','mushaf-next-page','ayah-wrap'])controls[id]={appendChild(){}};
 const c={Math,Number,String,Promise,Array,mushafPageRequest:0,mushafPageNumber:2,mushafPageVerses:[{verse_key:'old'}],state:{mushafFont:'classic',language:'en'},document:{getElementById:k=>controls[k],createElement:()=>({appendChild(){},addEventListener(){}})},window:{fetch:()=>new Promise(resolve=>resolvers.push(resolve))},loadMushafFont:()=>Promise.resolve({}),loadMushafChapterNames:()=>Promise.resolve({}),renderMushafPage:d=>rendered.push(d.page),showToast(){},formatText(){},t:k=>k,activateMushafVerse:v=>activated.push(v)};
 vm.createContext(c);vm.runInContext(fn('loadMushafPage')+fn('navigateMushafPage'),c);
 const old=c.loadMushafPage(2,false),current=c.loadMushafPage(3,false);
 resolvers[1]({ok:true,json:()=>Promise.resolve({page:3})});assert.equal(await current,true);
 resolvers[0]({ok:true,json:()=>Promise.resolve({page:2})});assert.equal(await old,undefined);assert.deepEqual(rendered,[3]);
 c.navigateMushafPage(1);resolvers[2]({ok:false});await new Promise(r=>setImmediate(r));assert.equal(activated.length,0,'A failed page change must not activate words from the previous page');
}
loading().then(()=>console.log(JSON.stringify({passed:true,wordCounts:sourceCounts,checks:['bad preferences','responsive defaults','size persistence','storage denial','exact Unicode and glyph round-trip','pinch zoom and vertical scroll do not turn pages','late response ignored','failed navigation preserves selected verse']}))).catch(e=>{console.error(e);process.exitCode=1;});
